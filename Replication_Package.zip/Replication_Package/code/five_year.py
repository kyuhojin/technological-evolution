import sys,json,hashlib
from pathlib import Path
import numpy as np,pandas as pd
from scipy.stats import norm
from scipy.linalg import qr
src=Path(sys.argv[1]);out=Path(sys.argv[2]);out.mkdir(exist_ok=True)
d=pd.read_stata(src,convert_categoricals=False)
cs=[f'p_fwd_{h}yr_appl_c_slfx_2026' for h in [3,5,7]]
vs=['p_sim_cent_abs_5yr','p_core_rb_w_5yr','p_num_clm_ln','p_team_inv_c_ln','p_team_inv_loc_c_d','a_pst_pat_c_ln','a_univ','p_asgn_c_d','a_cntr_d_non_us']
assert not d[cs].isna().any().any()
assert (d[cs[1]]>=d[cs[0]]).all() and (d[cs[2]]>=d[cs[1]]).all()
audit={'sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'N':len(d),'duplicate_ids':int(d.p_id.duplicated().sum()),'missing_counts':d[cs].isna().sum().to_dict(),'negative_increments':[int((d[cs[j+1]]<d[cs[j]]).sum()) for j in range(2)],'window_definition_status':'Names and nesting consistent; citation-construction code absent. Interval interpretations provisional pending coauthor confirmation. Complete windows assumed through Dec 31 2025, consistent with manuscript.'}
(out/'audit.json').write_text(json.dumps(audit,indent=2))
rng=np.random.default_rng(20261009);B=4000
amp=[];coh=[]
for stage,lo,hi in [('Formative',2008,2013),('Expansion',2014,2017),('Consolidation',2018,2020)]:
 base=d[d.p_yr_appl.between(lo,hi)].copy()
 for variant in ['All patents','Exclude top 1% within year']:
  groups=[]
  for yr,a in base.groupby('p_yr_appl'):
   if variant!='All patents':a=a[a[cs[1]]<=a[cs[1]].quantile(.99)]
   groups.append(a)
  weights=np.array([len(a) for a in groups],float);weights/=weights.sum()
  point=[];boots=np.zeros((B,2))
  for weight,a in zip(weights,groups):
   y=a[cs[1]].to_numpy(float);v=a[vs[:2]].to_numpy(float);n=len(a)
   delta=np.average(v,axis=0,weights=y)-v.mean(axis=0)
   point.append(delta)
   coh.append(dict(stage=stage,variant=variant,year=int(a.p_yr_appl.iloc[0]),N=n,semantic=delta[0],knowledge=delta[1]))
   for start in range(0,B,100):
    ix=rng.integers(0,n,(min(100,B-start),n))
    yy=y[ix];vv=v[ix];den=yy.sum(axis=1)
    if (den==0).any():raise ValueError('zero bootstrap citation total')
    boots[start:start+len(ix)]+=weight*((vv*yy[:,:,None]).sum(axis=1)/den[:,None]-vv.mean(axis=1))
  est=weights@np.array(point)
  for j,name in enumerate(['Semantic','Knowledge-base']):
   l,u=np.quantile(boots[:,j],[.025,.975])
   amp.append(dict(stage=stage,variant=variant,measure=name,N=sum(map(len,groups)),difference=est[j],lower=l,upper=u))
pd.DataFrame(amp).to_csv(out/'amplification.csv',index=False)
pd.DataFrame(coh).to_csv(out/'cohort_amplification.csv',index=False)
