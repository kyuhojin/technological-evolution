"""NB2 maximum likelihood, jointly estimated dispersion, robust sandwich inference.
Usage: python matched_nb.py analysis_20260921.dta output_directory
"""
import sys,json
from pathlib import Path
import numpy as np,pandas as pd
from scipy.optimize import minimize
from scipy.optimize._numdiff import approx_derivative
from scipy.special import gammaln,digamma
from scipy.stats import norm
src=Path(sys.argv[1]);out=Path(sys.argv[2]);out.mkdir(exist_ok=True,parents=True)
d=pd.read_stata(src,convert_categoricals=False);assert d.p_id.is_unique
vs=['p_sim_cent_abs_5yr','p_core_rb_w_5yr','p_num_clm_ln','p_team_inv_c_ln','p_team_inv_loc_c_d','a_pst_pat_c_ln','a_univ','p_asgn_c_d','a_cntr_d_non_us'];rows=[];details={}
for lo,hi in [(2008,2013),(2014,2017),(2018,2022),(2018,2020)]:
 a=d[d.p_yr_appl.between(lo,hi)].copy()
 x=pd.concat([a[vs],pd.get_dummies(a.p_yr_appl,prefix='year',drop_first=True,dtype=float),pd.get_dummies(a.topic.astype(int),prefix='topic',dtype=float).drop(columns='topic_6',errors='ignore')],axis=1).astype(float);x.insert(0,'intercept',1.)
 X=x.to_numpy();y=a.p_fwd_5yr_appl_c_slfx_2026.to_numpy(float);n,k=X.shape
 assert np.isfinite(X).all() and np.isfinite(y).all() and np.linalg.matrix_rank(X)==k
 def calc(theta,individual=False):
  eta=X@theta[:-1];mu=np.exp(eta);alpha=np.exp(theta[-1]);r=1/alpha
  ll=gammaln(y+r)-gammaln(r)-gammaln(y+1)+r*np.log(r)+y*eta-(r+y)*np.log(r+mu)
  sb=X*((y-mu)/(1+alpha*mu))[:,None]
  sr=digamma(y+r)-digamma(r)+np.log(r)+1-np.log(r+mu)-(r+y)/(r+mu)
  scores=np.column_stack([sb,-r*sr])
  if individual:return ll,scores
  return -ll.sum()/n,-scores.sum(axis=0)/n
 start=np.zeros(k+1);start[0]=np.log(y.mean());start[-1]=0
 fit=minimize(calc,start,jac=True,method='BFGS',options={'gtol':1e-10,'maxiter':3000})
 theta=fit.x;ll,U=calc(theta,True);H=approx_derivative(lambda t:calc(t)[1],theta,method='3-point')*n;H=(H+H.T)/2
 bread=np.linalg.inv(H);cov=bread@(U.T@U)@bread
 assert np.max(np.abs(calc(theta)[1]))<1e-6 and np.linalg.eigvalsh(H).min()>0
 se=np.sqrt(np.diag(cov));se1=se*np.sqrt(n/(n-k))
 row={'period':f'{lo}–{hi}','N':n,'alpha':float(np.exp(theta[-1])),'loglik':float(ll.sum()),'max_mean_score':float(np.max(np.abs(calc(theta)[1])))}
 for j,name in [(1,'semantic'),(2,'knowledge')]:
  row.update({name+'_b':theta[j],name+'_se_HC0':se[j],name+'_p_HC0':2*norm.sf(abs(theta[j]/se[j])),name+'_se_HC1':se1[j],name+'_p_HC1':2*norm.sf(abs(theta[j]/se1[j]))})
 rows.append(row);details[row['period']]={'names':list(x.columns)+['ln_alpha'],'params':theta.tolist(),'cov_HC0':cov.tolist(),'optimizer_message':str(fit.message)}
 print(row,flush=True)
 if hi==2020:
  # Independent optimization start at extended-model slope estimates is unnecessary;
  # confirm the optimum from a substantially different dispersion starting point.
  alt=start.copy();alt[-1]=np.log(3)
  f2=minimize(calc,alt,jac=True,method='BFGS',options={'gtol':1e-10,'maxiter':3000})
  assert abs(calc(f2.x)[0]-calc(theta)[0])<1e-9 and np.max(np.abs(f2.x-theta))<1e-4
  pd.DataFrame({'patent_id':a.p_id}).to_csv(out/'matched_sample_ids.csv',index=False)
pd.DataFrame(rows).to_csv(out/'nb_results.csv',index=False)
(out/'nb_details.json').write_text(json.dumps(details,indent=2))
