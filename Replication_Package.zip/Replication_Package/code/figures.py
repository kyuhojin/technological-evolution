import json,sys
from pathlib import Path
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
p=Path(sys.argv[1]);F=json.loads((p/'fits.json').read_text());periods=['2008_2013','2014_2017','2018_2020'];labels=['Formative\n2008–2013','Expansion\n2014–2017','Consolidation\n2018–2020'];x=np.arange(3)
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':12,'axes.spines.top':False,'axes.spines.right':False})
fig,ax=plt.subplots(figsize=(8,4.8))
for j,color,lab,shift in [(1,'#1f77b4','Semantic coreness',-.08),(2,'#ff7f0e','Knowledge-base coreness',.08)]:
 ys=[];los=[];his=[]
 for per in periods:
  f=F['Baseline_'+per];b=f['b'][j];se=f['se'][j];sd=f['sd'][j-1];ys.append(np.exp(b*sd));los.append(np.exp((b-1.95996398454*se)*sd));his.append(np.exp((b+1.95996398454*se)*sd))
 ys=np.array(ys);ax.errorbar(x+shift,ys,yerr=[ys-los,np.array(his)-ys],fmt='o',capsize=4,color=color,label=lab)
ax.axhline(1,color='#777',ls='--',lw=1);ax.set_xticks(x,labels);ax.set_ylabel('Incidence-rate ratio per 1 SD increase');ax.legend(frameon=False,loc='upper center',ncol=2,fontsize=10);ax.set_ylim(.79,1.56);fig.tight_layout();fig.savefig(p/'Figure3_Standardized_IRR.png',dpi=240);plt.close(fig)
fig,ax=plt.subplots(figsize=(8,4.8))
for spec,color,lab,shift in [('Baseline','#1f77b4','Centroid',-.08),('Pairwise','#ff7f0e','Pairwise',.08)]:
 b=np.array([F[spec+'_'+per]['b'][1] for per in periods]);se=np.array([F[spec+'_'+per]['se'][1] for per in periods]);ax.errorbar(x+shift,b,yerr=1.95996398454*se,fmt='o',capsize=4,color=color,label=lab)
ax.axhline(0,color='#777',ls='--',lw=1);ax.set_xticks(x,labels);ax.set_ylabel('Poisson coefficient');ax.set_xlabel('Developmental period');ax.set_title('PatentSBERTa semantic-coreness operationalizations');ax.legend(frameon=False,ncol=2);fig.tight_layout();fig.savefig(p/'FigureS2_Semantic_Operationalization.png',dpi=240)
