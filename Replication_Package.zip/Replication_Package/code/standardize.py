import sys,json
from pathlib import Path
import pandas as pd,numpy as np
from scipy.stats import norm,chi2
root=Path(sys.argv[1]);out=Path(sys.argv[2]);out.mkdir(exist_ok=True)
d=pd.read_stata(root/'analysis_20260921.dta',convert_categoricals=False)
vars=['p_sim_cent_abs_5yr','p_core_rb_w_5yr','p_num_clm_ln','p_team_inv_c_ln','p_team_inv_loc_c_d','a_pst_pat_c_ln','a_univ','p_asgn_c_d','a_cntr_d_non_us']
fits={};rows=[]
for spec,ranges in {'Baseline':[(2008,2013),(2014,2017),(2018,2020)],'A':[(2008,2012),(2013,2017),(2018,2020)],'B':[(2008,2014),(2015,2018),(2019,2020)],'Pairwise':[(2008,2013),(2014,2017),(2018,2020)],'Extended':[(2018,2022)]}.items():
 for lo,hi in ranges:
  a=d[d.p_yr_appl.between(lo,hi)].copy();vs=vars.copy()
  if spec=='Pairwise':vs[0]='p_sim_pair_abs_5yr'
  x=pd.concat([a[vs],pd.get_dummies(a.p_yr_appl,prefix='yr',drop_first=True,dtype=float),pd.get_dummies(a.topic.astype(int),prefix='topic',dtype=float).drop(columns='topic_6')],axis=1).astype(float);x.insert(0,'intercept',1.)
  X=x.to_numpy();y=a.p_fwd_5yr_appl_c_slfx_2026.to_numpy(float);n=len(a);b=np.zeros(X.shape[1]);b[0]=np.log(y.mean())
  for _ in range(200):
   mu=np.exp(X@b);step=np.linalg.solve(X.T@(mu[:,None]*X),X.T@(y-mu));ll=np.sum(y*(X@b)-mu);s=1
   while np.sum(y*(X@(b+s*step))-np.exp(X@(b+s*step)))<ll-1e-9:s/=2
   b+=s*step
   if max(abs(s*step))<1e-9:break
  mu=np.exp(X@b);bread=np.linalg.inv(X.T@(mu[:,None]*X));u=X*(y-mu)[:,None];cov=bread@(u.T@u)@bread*n/(n-1);se=np.sqrt(np.diag(cov));p=2*norm.sf(abs(b/se))
  key=f'{spec}_{lo}_{hi}';fits[key]={'n':n,'names':x.columns.tolist(),'b':b.tolist(),'se':se.tolist(),'p':p.tolist(),'cov':cov.tolist(),'sd':[float(a[vs[0]].std()),float(a[vs[1]].std())]}
  for j,nm in enumerate(x.columns):rows.append({'model':key,'variable':nm,'N':n,'b':b[j],'se':se[j],'p':p[j],'lo':b[j]-norm.ppf(.975)*se[j],'hi':b[j]+norm.ppf(.975)*se[j]})
nb=json.loads((root/'nb_details.json').read_text())
for period,f in nb.items():
 lo,hi=map(int,period.split('–'));n=int(d.p_yr_appl.between(lo,hi).sum());b=np.array(f['params']);cov=np.array(f['cov_HC0'])*n/(n-1);se=np.sqrt(np.diag(cov));p=2*norm.sf(abs(b/se));key=f'NB_{lo}_{hi}'
 fits[key]={'n':n,'names':f['names'],'b':b.tolist(),'se':se.tolist(),'p':p.tolist(),'cov':cov.tolist()}
 for j,nm in enumerate(f['names']):rows.append({'model':key,'variable':nm,'N':n,'b':b[j],'se':se[j],'p':p[j],'lo':b[j]-norm.ppf(.975)*se[j],'hi':b[j]+norm.ppf(.975)*se[j]})
cross=[]
for j,nm in [(1,'semantic'),(2,'knowledge')]:
 fs=[fits[f'Baseline_{lo}_{hi}'] for lo,hi in [(2008,2013),(2014,2017),(2018,2020)]];b=np.array([f['b'][j] for f in fs]);v=np.diag([f['se'][j]**2 for f in fs]);C=np.array([[1,-1,0],[1,0,-1]]);delta=C@b;q=delta@np.linalg.solve(C@v@C.T,delta)
 cross.append({'variable':nm,'comparison':'Joint equality','stat':q,'p':chi2.sf(q,2)})
 for i,k in [(0,1),(0,2),(1,2)]:
  diff=b[i]-b[k];se=np.sqrt(v[i,i]+v[k,k]);z=diff/se;cross.append({'variable':nm,'comparison':f'{i}-{k}','difference':diff,'se':se,'stat':z,'p':2*norm.sf(abs(z))})
(out/'fits.json').write_text(json.dumps(fits,indent=2));pd.DataFrame(rows).to_csv(out/'all_estimates.csv',index=False);pd.DataFrame(cross).to_csv(out/'cross_stage.csv',index=False)
print(pd.DataFrame(rows).query("variable in ['p_sim_cent_abs_5yr','p_sim_pair_abs_5yr','p_core_rb_w_5yr']").to_string(index=False));print(pd.DataFrame(cross).to_string(index=False))
