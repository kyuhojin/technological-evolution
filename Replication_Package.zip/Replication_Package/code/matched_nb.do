* Run from the directory containing analysis_20260921.dta.
clear all
set more off
use "analysis_20260921.dta", clear
isid p_id
local controls p_num_clm_ln p_team_inv_c_ln p_team_inv_loc_c_d a_pst_pat_c_ln a_univ p_asgn_c_d a_cntr_d_non_us
poisson p_fwd_5yr_appl_c_slfx_2026 p_core_rb_w_5yr p_sim_cent_abs_5yr `controls' i.p_yr_appl ib6.topic if inrange(p_yr_appl,2018,2020), vce(robust)
estimates store poisson_matched
nbreg p_fwd_5yr_appl_c_slfx_2026 p_core_rb_w_5yr p_sim_cent_abs_5yr `controls' i.p_yr_appl ib6.topic if inrange(p_yr_appl,2018,2020), vce(robust)
estimates store nb_matched
assert e(N)==5504
* Optional extended-window NB2 check, as in the original do-file.
nbreg p_fwd_5yr_appl_c_slfx_2026 p_core_rb_w_5yr p_sim_cent_abs_5yr `controls' i.p_yr_appl ib6.topic if inrange(p_yr_appl,2018,2022), vce(robust)
estimates store nb_extended
* Stata's finite-sample sandwich scaling may differ slightly from the HC0
* standard errors used for the new Python result; coefficients are identical.
