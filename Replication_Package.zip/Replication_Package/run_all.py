from pathlib import Path
import subprocess, sys, shutil
root=Path(__file__).resolve().parent
out=root/'regenerated';out.mkdir(exist_ok=True)
shutil.copy2(root/'analysis_20260921.dta',out/'analysis_20260921.dta')
def run(name,*args):
    subprocess.run([sys.executable,str(root/'code'/name),*[str(x) for x in args]],check=True)
run('matched_nb.py',out/'analysis_20260921.dta',out)
run('standardize.py',out,out)
run('figures.py',out)
for horizon in ['three_year','five_year']:
    dest=out/horizon;dest.mkdir(exist_ok=True)
    run(horizon+'.py',out/'analysis_20260921.dta',dest)
print('Completed. Outputs: '+str(out))
